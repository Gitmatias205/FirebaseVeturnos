package com.proyecto.roomveturnos.ui.theme.ui.servicios

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController

@Composable
fun PeluqueriaScreen(navController: NavController) {
    val context = LocalContext.current

    Box(modifier = Modifier.fillMaxSize()) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ===== Video del servicio =====
            AndroidView(
                factory = {
                    VideoView(it).apply {
                        setVideoURI(Uri.parse("android.resource://${context.packageName}/raw/video_peluqueria"))

                        val mediaController = MediaController(context)
                        mediaController.setAnchorView(this)
                        setMediaController(mediaController)

                        start()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )

            // ===== Título y descripción =====
            Text(
                "Peluquería 🐶🐱",
                style = MaterialTheme.typography.headlineMedium,
                color = Color(0xFF00897B)
            )
            Text(
                "Agenda citas para el cuidado y aseo de tu mascota. Nuestro equipo brinda atención especial para mantenerlos limpios, cómodos y saludables.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.DarkGray
            )

            // ===== Beneficios =====
            Text(
                "Beneficios del servicio:",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF00695C)
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BeneficioItem("Baños relajantes y seguros")
                BeneficioItem("Corte de pelo según la raza")
                BeneficioItem("Limpieza de oídos y uñas")
                BeneficioItem("Tratamientos antipulgas y desparasitantes")
            }

            // ===== Contacto =====
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2F1)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Contacto para citas 📞",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF004D40)
                    )
                    Text("Teléfono: +593 987 654 321", fontSize = 16.sp, color = Color.Black)
                    Text("Horario: Lunes a Sábado - 9:00 a 18:00", fontSize = 14.sp, color = Color.DarkGray)
                }
            }
        }

        // ===== Botón volver en esquina superior derecha =====
        Button(
            onClick = {
                navController.navigate("dashboard") {
                    popUpTo("dashboard") { inclusive = true }
                }
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .height(40.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00897B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("← Volver", color = Color.White, fontSize = 14.sp)
        }
    }
}

@Composable
fun BeneficioItem(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        Surface(
            modifier = Modifier.size(26.dp),
            shape = CircleShape,
            color = Color(0xFF00897B).copy(alpha = 0.15f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("✔", color = Color(0xFF00897B), fontSize = 14.sp)
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = Color(0xFF424242))
    }
}
