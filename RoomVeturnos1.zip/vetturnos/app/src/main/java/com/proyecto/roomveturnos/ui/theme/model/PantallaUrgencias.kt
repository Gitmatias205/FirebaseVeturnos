package com.proyecto.roomveturnos.ui.theme.ui.servicios

import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController

@Composable
fun UrgenciasScreen(navController: NavController) {
    val context = LocalContext.current

    Box(modifier = Modifier.fillMaxSize()) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // VIDEO en la parte superior
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                factory = { ctx ->
                    VideoView(ctx).apply {
                        val videoPath = "android.resource://${ctx.packageName}/raw/video_servicios"
                        setVideoPath(videoPath)
                        setOnCompletionListener { start() } // loop automático
                        start()
                    }
                }
            )

            // Títulos principales
            Text(
                "Urgencias 🏥",
                style = MaterialTheme.typography.headlineMedium,
                color = Color(0xFFD32F2F)
            )
            Text(
                "Atención inmediata para tu mascota en caso de emergencias graves. Nuestro equipo está disponible para brindarte ayuda rápida y profesional.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.DarkGray
            )

            // Lista de emergencias comunes
            Text(
                "Casos más comunes:",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF1565C0)
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EmergenciaItem("Accidentes o golpes fuertes")
                EmergenciaItem("Dificultad para respirar")
                EmergenciaItem("Envenenamiento o ingestión de objetos")
                EmergenciaItem("Convulsiones")
                EmergenciaItem("Sangrado abundante")
            }

            // Contacto rápido
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Contacto de urgencias 🚨",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFFB71C1C)
                    )
                    Text("Teléfono: +593 999 111 222", fontSize = 16.sp, color = Color.Black)
                    Text("Atención 24/7", fontSize = 14.sp, color = Color.DarkGray)
                }
            }
        }

        // Botón volver en esquina superior derecha
        Button(
            onClick = {
                navController.navigate("dashboard") {
                    popUpTo("dashboard") { inclusive = true }
                }
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .height(40.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("← Volver", color = Color.White, fontSize = 14.sp)
        }
    }
}

@Composable
fun EmergenciaItem(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        Surface(
            modifier = Modifier.size(26.dp),
            shape = CircleShape,
            color = Color(0xFFD32F2F).copy(alpha = 0.15f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("!", color = Color(0xFFD32F2F), fontSize = 14.sp)
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = Color(0xFF424242))
    }
}
