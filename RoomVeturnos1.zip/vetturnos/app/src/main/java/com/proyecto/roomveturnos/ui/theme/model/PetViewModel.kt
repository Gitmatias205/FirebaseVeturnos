package com.proyecto.roomveturnos.ui.theme.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.proyecto.roomveturnos.ui.theme.model.AppDatabase
import com.proyecto.roomveturnos.ui.theme.model.Pet
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PetViewModel(application: Application) : AndroidViewModel(application) {

    private val petDao = AppDatabase.getDatabase(application).petDao()

    private val _petState = MutableStateFlow<Pet?>(null)
    val petState: StateFlow<Pet?> get() = _petState

    // Carga la mascota del usuario
    fun loadPet(userEmail: String) {
        viewModelScope.launch {
            val pet = petDao.getPetByUser(userEmail)
            _petState.value = pet
        }
    }

    // Guarda o actualiza la mascota del usuario
    fun savePet(
        userEmail: String,
        nombre: String,
        tipo: String,
        edad: Int,
        vacunasUri: String,
        fotoUri: String
    ) {
        viewModelScope.launch {
            val pet = Pet(
                id = 0, // Room generará automáticamente si no existe
                userEmail = userEmail,
                nombre = nombre,
                tipo = tipo,
                edad = edad,
                vacunasUri = vacunasUri,
                fotoUri = fotoUri
            )
            petDao.insertPet(pet) // INSERT con REPLACE actualizará si ya existe
            _petState.value = pet
        }
    }
}
