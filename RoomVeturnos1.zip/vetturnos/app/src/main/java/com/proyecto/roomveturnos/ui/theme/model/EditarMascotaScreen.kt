package com.proyecto.roomveturnos.ui.theme.ui.mascota

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.proyecto.roomveturnos.ui.theme.viewmodel.PetViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditarMascotaScreen(
    navController: NavController,
    petViewModel: PetViewModel,
    userEmail: String
) {
    var nombreMascota by remember { mutableStateOf(TextFieldValue("")) }
    var tipoMascota by remember { mutableStateOf(TextFieldValue("")) }
    var edadMascota by remember { mutableStateOf(TextFieldValue("")) }
    var vacunasFileName by remember { mutableStateOf("No seleccionado") }
    var fotoUri by remember { mutableStateOf<Uri?>(null) }

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val petState by petViewModel.petState.collectAsState()
    LaunchedEffect(userEmail) { petViewModel.loadPet(userEmail) }
    LaunchedEffect(petState) {
        petState?.let { pet ->
            nombreMascota = TextFieldValue(pet.nombre)
            tipoMascota = TextFieldValue(pet.tipo)
            edadMascota = TextFieldValue(pet.edad.toString())
            vacunasFileName = pet.vacunasUri
            fotoUri = if (pet.fotoUri.isNotEmpty()) Uri.parse(pet.fotoUri) else null
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { fotoUri = it }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Editar Mascota 🐾") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF2E7D32),
                    titleContentColor = Color.White
                )
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF5F5F5))
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Imagen ovalada
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
                    .clickable { launcher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                fotoUri?.let {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(it)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Foto Mascota",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = nombreMascota,
                onValueChange = { nombreMascota = it },
                label = { Text("Nombre de la mascota") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = tipoMascota,
                onValueChange = { tipoMascota = it },
                label = { Text("Tipo de mascota") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Edad sin KeyboardOptions
            OutlinedTextField(
                value = edadMascota,
                onValueChange = { newValue ->
                    // Solo permitir números
                    if (newValue.text.all { it.isDigit() }) edadMascota = newValue
                },
                label = { Text("Edad de la mascota (años)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = { /* TODO: Subir archivo de vacunas */ }, modifier = Modifier.fillMaxWidth()) {
                Text("Subir carnet de vacunas")
            }
            Text("Archivo: $vacunasFileName", fontSize = 14.sp, color = Color.Gray)

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val edadInt = edadMascota.text.toIntOrNull() ?: 0
                    petViewModel.savePet(
                        userEmail,
                        nombreMascota.text,
                        tipoMascota.text,
                        edadInt,
                        vacunasFileName,
                        fotoUri?.toString() ?: ""
                    )
                    scope.launch { snackbarHostState.showSnackbar("Información de la mascota guardada correctamente") }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar cambios", fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate("dashboard") { popUpTo("dashboard") { inclusive = true } } },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Volver al Dashboard", fontSize = 16.sp, color = Color.White)
            }
        }
    }
}
