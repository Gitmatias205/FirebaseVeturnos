package com.proyecto.roomveturnos.ui.theme.model

class PetRepository(private val petDao: PetDao) {

    suspend fun savePet(pet: Pet) = petDao.insertPet(pet)

    suspend fun getPetByUser(email: String): Pet? = petDao.getPetByUser(email)
}
