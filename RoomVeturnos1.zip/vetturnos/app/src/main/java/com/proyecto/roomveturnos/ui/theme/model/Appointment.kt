package com.proyecto.roomveturnos.ui.theme.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "appointment")
data class Appointment(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,            // ID autogenerado por Room
    val userEmail: String,       // Email del usuario que crea la cita
    val fecha: String,           // Fecha de la cita
    val descripcion: String      // Descripción o servicio de la cita
)
