package com.proyecto.roomveturnos.ui.theme.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.proyecto.roomveturnos.ui.theme.model.Appointment
import com.proyecto.roomveturnos.ui.theme.viewmodel.UserViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    userViewModel: UserViewModel,
    userEmail: String,
    navController: NavController,
    onLogout: () -> Unit
) {
    var appointments by remember { mutableStateOf(emptyList<Appointment>()) }
    var menuExpanded by remember { mutableStateOf(false) }

    // Cargar turnos
    LaunchedEffect(userEmail) {
        userViewModel.getAppointments(userEmail) { list ->
            appointments = list
        }
    }

    // Estados para el formulario de consulta
    var nombre by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("") }
    var mensaje by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Clínica Veterinaria 🐶🐱") },
                actions = {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.Menu, contentDescription = "Menú")
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        // Editar Mascota
                        DropdownMenuItem(
                            text = { Text("Editar Mascota") },
                            onClick = {
                                menuExpanded = false
                                navController.navigate("editarMascota")
                            },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                        )
                        // Cerrar sesión
                        DropdownMenuItem(
                            text = { Text("Cerrar sesión") },
                            onClick = {
                                menuExpanded = false
                                onLogout()
                            },
                            leadingIcon = { Icon(Icons.Default.ExitToApp, contentDescription = null) }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF2E7D32),
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .background(Color(0xFFF5F5F5))
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // ===== Botones de servicios fijos =====
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { navController.navigate("peluqueria") },
                    modifier = Modifier.weight(1f)
                ) { Text("Peluquería") }

                Button(
                    onClick = { navController.navigate("urgencias") },
                    modifier = Modifier.weight(1f)
                ) { Text("Urgencias") }

                Button(
                    onClick = { navController.navigate("servicioMedico") },
                    modifier = Modifier.weight(1f)
                ) { Text("Servicio Médico") }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ===== Lista de turnos =====
            Text("Tus turnos:", fontSize = 18.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(8.dp))

            if (appointments.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No tienes turnos registrados 🐾", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp)
                ) {
                    items(appointments) { appointment ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Mascota: ${appointment.descripcion}",
                                    fontSize = 16.sp,
                                    color = Color.Black
                                )
                                Text(
                                    text = "Fecha: ${appointment.fecha}",
                                    fontSize = 14.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ===== Formulario básico de consulta =====
            Text("Consulta o duda sobre un servicio:", fontSize = 18.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = correo,
                onValueChange = { correo = it },
                label = { Text("Correo") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = mensaje,
                onValueChange = { mensaje = it },
                label = { Text("Mensaje / Consulta") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { /* Pendiente: enviar consulta */ },
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Enviar")
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
