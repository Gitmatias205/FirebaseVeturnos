package com.proyecto.roomveturnos.ui.theme.model

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TurnoDao {

    @Insert
    suspend fun insertTurno(turno: Turno)

    @Delete
    suspend fun deleteTurno(turno: Turno)

    @Query("SELECT * FROM turno WHERE userEmail = :email")
    suspend fun getTurnosByUser(email: String): List<Turno>
}
