package com.proyecto.roomveturnos.ui.theme.model

import android.content.Context

class TurnoRepository(context: Context) {

    // Obtener el DAO de turnos desde la base de datos
    private val turnoDao: TurnoDao = AppDatabase.getDatabase(context).turnoDao()

    // Agregar un nuevo turno
    suspend fun addTurno(turno: Turno) {
        turnoDao.insertTurno(turno)
    }

    // Eliminar un turno existente
    suspend fun removeTurno(turno: Turno) {
        turnoDao.deleteTurno(turno)
    }

    // Obtener todos los turnos de un usuario específico
    suspend fun getTurnosByUser(email: String): List<Turno> {
        return turnoDao.getTurnosByUser(email)
    }
}
