package com.proyecto.roomveturnos.ui.theme.model

import android.content.Context

class UserRepository(context: Context) {

    private val userDao: UserDao = AppDatabase.getDatabase(context).userDao()
    private val appointmentDao: AppointmentDao = AppDatabase.getDatabase(context).appointmentDao()

    // ================== USUARIOS ==================
    suspend fun addUser(user: User) {
        userDao.addUser(user)
    }

    suspend fun getUserByEmail(email: String): User? {
        return userDao.getUserByEmail(email)
    }

    // ================== CITAS ==================
    suspend fun addAppointment(appointment: Appointment) {
        appointmentDao.addAppointment(appointment)
    }

    suspend fun getAppointmentsByUser(email: String): List<Appointment> {
        return appointmentDao.getAppointmentsByUser(email)
    }

    suspend fun deleteAppointmentById(id: Int) {
        appointmentDao.deleteAppointmentById(id)
    }
}
