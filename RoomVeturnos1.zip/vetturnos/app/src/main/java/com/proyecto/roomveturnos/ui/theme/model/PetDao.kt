package com.proyecto.roomveturnos.ui.theme.model

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface PetDao {

    @Query("SELECT * FROM pets WHERE userEmail = :email LIMIT 1")
    suspend fun getPetByUser(email: String): Pet?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPet(pet: Pet)

    @Update
    suspend fun updatePet(pet: Pet)
}
