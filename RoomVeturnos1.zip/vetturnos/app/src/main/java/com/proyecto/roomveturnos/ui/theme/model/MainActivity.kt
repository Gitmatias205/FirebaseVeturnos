package com.proyecto.roomveturnos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.proyecto.roomveturnos.ui.theme.ui.admin.AdminPanelScreen
import com.proyecto.roomveturnos.ui.theme.ui.dashboard.DashboardScreen
import com.proyecto.roomveturnos.ui.theme.ui.login.LoginScreen
import com.proyecto.roomveturnos.ui.theme.ui.mascota.EditarMascotaScreen
import com.proyecto.roomveturnos.ui.theme.ui.register.RegisterScreen
import com.proyecto.roomveturnos.ui.theme.ui.servicios.PeluqueriaScreen
import com.proyecto.roomveturnos.ui.theme.ui.servicios.UrgenciasScreen
import com.proyecto.roomveturnos.ui.theme.ui.servicios.ServicioMedicoScreen
import com.proyecto.roomveturnos.ui.theme.viewmodel.PetViewModel
import com.proyecto.roomveturnos.ui.theme.viewmodel.UserViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                // Instanciamos ViewModels
                val userViewModel: UserViewModel = viewModel(
                    factory = androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(application)
                )
                val petViewModel: PetViewModel = viewModel(
                    factory = androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(application)
                )

                var userRole = ""
                var currentUserEmail = ""

                val navController = rememberNavController()

                NavHost(navController = navController, startDestination = "login") {

                    // ===== Login =====
                    composable("login") {
                        LoginScreen(
                            userViewModel = userViewModel,
                            onLoginSuccess = { role, email ->
                                userRole = role
                                currentUserEmail = email
                                navController.navigate(if (role == "admin") "admin" else "dashboard") {
                                    popUpTo("login") { inclusive = true }
                                }
                            },
                            onNavigateToRegister = { navController.navigate("register") }
                        )
                    }

                    // ===== Registro =====
                    composable("register") {
                        RegisterScreen(
                            userViewModel = userViewModel,
                            onRegistrationSuccess = {
                                navController.navigate("login") {
                                    popUpTo("register") { inclusive = true }
                                }
                            }
                        )
                    }

                    // ===== Dashboard =====
                    composable("dashboard") {
                        DashboardScreen(
                            userViewModel = userViewModel,
                            userEmail = currentUserEmail,
                            navController = navController,
                            onLogout = {
                                navController.navigate("login") {
                                    popUpTo("dashboard") { inclusive = true }
                                }
                            }
                        )
                    }

                    // ===== Editar Mascota =====
                    composable("editarMascota") {
                        EditarMascotaScreen(
                            navController = navController,
                            petViewModel = petViewModel,
                            userEmail = currentUserEmail
                        )
                    }

                    // ===== Panel admin =====
                    composable("admin") {
                        AdminPanelScreen(
                            navController = navController,
                            appointments = listOf()
                        )
                    }

                    // ===== Servicios =====
                    composable("peluqueria") { PeluqueriaScreen(navController) }
                    composable("urgencias") { UrgenciasScreen(navController) }
                    composable("servicioMedico") { ServicioMedicoScreen(navController) }
                }
            }
        }
    }
}
