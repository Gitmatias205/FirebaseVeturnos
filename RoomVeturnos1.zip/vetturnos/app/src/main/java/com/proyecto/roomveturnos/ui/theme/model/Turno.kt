package com.proyecto.roomveturnos.ui.theme.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "turno")
data class Turno(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userEmail: String,
    val fecha: String,
    val descripcion: String
)
