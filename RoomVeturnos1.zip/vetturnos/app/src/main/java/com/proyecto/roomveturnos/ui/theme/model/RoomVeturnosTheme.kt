package com.proyecto.roomveturnos.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Definir esquema de colores claro
private val LightColors = lightColorScheme(
    primary = Color(0xFF4CAF50),       // Verde principal
    secondary = Color(0xFF81C784),     // Verde secundario
    background = Color(0xFFE8F5E9),    // Fondo suave
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black
)

@Composable
fun RoomVeturnosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
