package com.proyecto.roomveturnos.ui.theme.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.proyecto.roomveturnos.ui.theme.model.Appointment
import com.proyecto.roomveturnos.ui.theme.model.User
import com.proyecto.roomveturnos.ui.theme.model.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UserViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = UserRepository(application)

    private val adminEmail = "admin@vet.com"
    private val adminPassword = "admin123"

    // Registro de usuario normal
    fun registerUser(nombre: String, email: String, password: String, onSuccess: () -> Unit, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val user = User(nombre = nombre, email = email, password = password)
                repository.addUser(user)
                onSuccess()
            } catch (e: Exception) {
                onError("Error al registrar usuario: ${e.message}")
            }
        }
    }

    // Login
    suspend fun loginUser(email: String, password: String): String {
        return withContext(Dispatchers.IO) {
            try {
                if (email == adminEmail && password == adminPassword) {
                    "admin"
                } else {
                    val user = repository.getUserByEmail(email)
                    if (user != null && user.password == password) "user" else ""
                }
            } catch (e: Exception) {
                ""
            }
        }
    }

    // Agregar cita
    fun addAppointment(userEmail: String, fecha: String, descripcion: String, onSuccess: () -> Unit, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val appointment = Appointment(userEmail = userEmail, fecha = fecha, descripcion = descripcion)
                repository.addAppointment(appointment)
                onSuccess()
            } catch (e: Exception) {
                onError("Error al agregar cita: ${e.message}")
            }
        }
    }

    // Obtener citas de un usuario
    fun getAppointments(userEmail: String, callback: (List<Appointment>) -> Unit) {
        viewModelScope.launch {
            val appointments = repository.getAppointmentsByUser(userEmail)
            callback(appointments)
        }
    }

    // Eliminar cita
    fun deleteAppointment(id: Int, onSuccess: () -> Unit, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.deleteAppointmentById(id)
                onSuccess()
            } catch (e: Exception) {
                onError("Error al eliminar cita: ${e.message}")
            }
        }
    }
}
