package com.proyecto.roomveturnos.ui.theme.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pets")
data class Pet(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userEmail: String,
    val nombre: String,
    val tipo: String,
    val edad: Int,
    val vacunasUri: String,
    val fotoUri: String
)
