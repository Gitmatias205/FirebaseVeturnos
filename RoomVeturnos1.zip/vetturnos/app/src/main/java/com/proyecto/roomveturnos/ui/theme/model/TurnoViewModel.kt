package com.proyecto.roomveturnos.ui.theme.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.proyecto.roomveturnos.ui.theme.model.Turno
import com.proyecto.roomveturnos.ui.theme.model.TurnoRepository
import kotlinx.coroutines.launch

class TurnoViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TurnoRepository(application)

    // Función para agregar un nuevo turno
    fun addTurno(userEmail: String, fecha: String, descripcion: String, onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            val nuevoTurno = Turno(
                userEmail = userEmail,
                fecha = fecha,
                descripcion = descripcion
            )
            repository.addTurno(nuevoTurno)
            onSuccess?.invoke()
        }
    }

    // Función para eliminar un turno existente
    fun removeTurno(turno: Turno, onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.removeTurno(turno)
            onSuccess?.invoke()
        }
    }

    // Función para obtener todos los turnos de un usuario
    fun getTurnosByUser(userEmail: String, onResult: (List<Turno>) -> Unit) {
        viewModelScope.launch {
            val turnos = repository.getTurnosByUser(userEmail)
            onResult(turnos)
        }
    }
}
