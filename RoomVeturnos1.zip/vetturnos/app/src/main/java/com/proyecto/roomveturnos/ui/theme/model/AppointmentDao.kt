package com.proyecto.roomveturnos.ui.theme.model

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AppointmentDao {

    @Insert
    suspend fun addAppointment(appointment: Appointment)

    @Query("SELECT * FROM appointment WHERE userEmail = :email")
    suspend fun getAppointmentsByUser(email: String): List<Appointment>

    @Query("DELETE FROM appointment WHERE id = :id")
    suspend fun deleteAppointmentById(id: Int)
}
