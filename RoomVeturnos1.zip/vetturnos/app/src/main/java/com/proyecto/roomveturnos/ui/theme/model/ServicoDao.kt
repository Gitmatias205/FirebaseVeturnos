package com.proyecto.roomveturnos.ui.theme.model

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ServicioDao {

    // Insertar un nuevo servicio
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServicio(servicio: Servicio)

    // Insertar varios servicios de una sola vez
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllServicios(servicios: List<Servicio>)

    // Obtener todos los servicios
    @Query("SELECT * FROM servicios")
    suspend fun getAllServicios(): List<Servicio>

    // Buscar un servicio por ID
    @Query("SELECT * FROM servicios WHERE id = :id")
    suspend fun getServicioById(id: Int): Servicio?
}
