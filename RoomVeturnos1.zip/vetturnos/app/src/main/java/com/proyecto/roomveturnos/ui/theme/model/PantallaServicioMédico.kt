package com.proyecto.roomveturnos.ui.theme.ui.servicios

import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.proyecto.roomveturnos.ui.theme.viewmodel.TurnoViewModel

@Composable
fun ServicioMedicoScreen(
    navController: NavController,
    turnoViewModel: TurnoViewModel = viewModel()
) {
    val context = LocalContext.current

    var email by remember { mutableStateOf("") }
    var fecha by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var mensaje by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // ===== VIDEO =====
            AndroidView(
                factory = {
                    VideoView(it).apply {
                        setVideoPath("android.resource://${context.packageName}/raw/video_medico")
                        val mediaController = MediaController(it)
                        mediaController.setAnchorView(this)
                        setMediaController(mediaController)
                        start()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            )

            // ===== Encabezado =====
            Text(
                "Servicio Médico 🩺",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFF2E7D32)
            )
            Text(
                "Cuidamos la salud de tu mascota de manera profesional y cercana.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )

            // ===== FORMULARIO TURNO =====
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Reserva tu turno 📅",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF2E7D32)
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Correo") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = fecha,
                        onValueChange = { fecha = it },
                        label = { Text("Fecha (dd/mm/aaaa)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = descripcion,
                        onValueChange = { descripcion = it },
                        label = { Text("Descripción (consulta, vacuna, etc.)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            if (email.isNotEmpty() && fecha.isNotEmpty() && descripcion.isNotEmpty()) {
                                turnoViewModel.addTurno(
                                    userEmail = email,
                                    fecha = fecha,
                                    descripcion = descripcion
                                ) {
                                    mensaje = "Turno registrado con éxito ✅"
                                    email = ""; fecha = ""; descripcion = ""
                                }
                            } else {
                                mensaje = "Por favor completa todos los campos ❌"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("Guardar Turno", color = Color.White)
                    }

                    mensaje?.let {
                        Text(it, color = if (it.contains("✅")) Color(0xFF2E7D32) else Color.Red)
                    }
                }
            }

            // ===== CONTACTO SIMPLE =====
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Contacto 📞",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF1565C0)
                    )
                    Text("Teléfono: +593 987 654 321", fontSize = 15.sp, color = Color.Black)
                }
            }

            // ===== BOTÓN VOLVER (ABAJO) =====
            Button(
                onClick = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Volver", color = Color.White, fontSize = 14.sp)
            }
        }
    }
}
